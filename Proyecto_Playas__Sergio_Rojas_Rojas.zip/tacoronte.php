<?Php 
$servidor = "localhost"; 
$usuario_bd = "dwes";  
$password_bd = "abc123.";  
$basedatos = "playasdb";  


$conexion = mysql_connect($servidor,$usuario_bd,$password_bd); 
if (!$conexion) 
{ 
    echo "Error conectando a la base de datos."; 
    exit(); 
} 

$resultado=mysql_select_db($basedatos,$conexion); 
if (!$resultado) 
{ 
    echo "Error seleccionando la base de datos."; 
    exit(); 
} 
?> 
<html> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"> 
<title>Seleccionar Municipios</title> 
</head> 

<body> 
<select name="sel_vend" id="sel_vend"> 
            <?php  
$cod_ve = array(); 
$cod_vn = array(); 
         
$consulta= "SELECT * FROM playas where idMun=1"; 
                 $resultado = mysql_query($consulta,$conexion) or die('La consulta fall&oacute;: ' . mysql_error()); 
               
while($linea = mysql_fetch_array($resultado)){ 
     
             
echo " <option value=\" Elija el Municipio".$linea[0]."\">".$linea[2]."</option>\n"; 
         
              } 
			  
         
            
              ?> 
          </select>
		  
<br>		  
<input type='Submit' value="Ir a Municipios" name=Accion id=Accion OnClick="window.location.href='mostrarmunicipios.php'">  
</body>
</html>