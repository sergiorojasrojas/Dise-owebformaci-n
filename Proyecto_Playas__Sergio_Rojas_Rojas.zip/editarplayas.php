<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "
http://www.w3.org/TR/html4/loose.dtd">

<!-- Esta pagina se va a encargar de las siguientes tareas: -->
<!-- 
    Primeramente va a mostrar los datos de las playas seleccionado en la página anterior  dentro de un formulario que permita cambiarlos, y dos botones: 
    "Actualizar" y "Cancelar". El formulario se enviará a la página web  "actualizar.php".
 -->
<html>
    <head><div style="text-align:left;padding:1em 0;"> <h3><a style="text-decoration:none;" href="https://www.zeitverschiebung.net/es/country/gb"><span
		style="color:gray;">Hora actual en</span><br />Islas Canarias Ciudad de La Laguna Tenerife</a></h3> <iframe 
		src="https://www.zeitverschiebung.net/clock-widget-iframe-v2?language=es&size=medium&timezone=Europe%2FLondon"
		width="100%" height="115" frameborder="0" seamless></iframe> </div>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Sergio Rojas Rojas. PAGINA WEB EDICION DE PLAYAS</title>
        <link href="playas.css" rel="stylesheet" type="text/css">
		<script language="JavaScript" type="text/javascript">

function alertMessage(){
     alert ("Bienvenido a la pagina web de Sergio Rojas Rojas: EDICION DE PLAYASS!")
}

</script>
    </head>
		
    <body>
        <?php
			// Si se ha recibido el idmun de algúna ´playa, se almacena en la variable codigo
            if (isset($_POST['idMun'])) $codigo = $_POST['idMun'];
			// Con este codigo se abre la base de datos como objeto PDO y se almacenan los posibles errores
            try {
                $dwes = new PDO("mysql:host=localhost;dbname=playasdb", "dwes", "abc123.");
                $dwes->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            }catch (PDOException $e) {
                $error = $e->getCode();
                $mensaje = $e->getMessage();
            }
		?>
		<div id="encabezado">
			<h1> Edici&oacute;n de Playas</h1>
		</div>
		<div id="contenido">
			<h2>Playas:</h2>
			<?php
				// Con este código si se recibio un idMun de playas y no se produjo ningun error
				//  entonces mostraremos los datos de esas playas
				if (!isset($error) && isset($codigo)) {
					// Necesitamos seleccionar el registro que coincide con el código recibido
					$sql = <<<SQL
						SELECT idMunicipio,nombre
						FROM municipio
						WHERE municipio.idMunicipio='$codigo'
SQL;
					// Aqui primeramente tedremos que ejecutar la consulta anterior
					$resultado = $dwes->query($sql);
					// si se ha encontrado el registro
					if($resultado) {
						//Después con este código nos centraremos en  leer el primer registro encontrado (y único, ya que buscamos por su campo clave)
						$row = $resultado->fetch();
						// Creamos un formulario que envíe los datos via post al fichero actualizar.php
						echo "<form id='form_edit' action='actualizarplayas.php' method='post'>";
						// metemos los datos del registro en sus correspondientes variables
						$codigo=$row['idMun'];
						$idPlaya=$row['idPlaya'];
						$nombre=$row['nombre'];
						$descripcion=$row['descripcion'];
							$direccion=$row['direccion'];
							$playaSize=$row['playaSize'];
							$longitud=$row['longitud'];
							$latitud=$row['latitud'];
							$imagen=$row['imagen'];
						
						echo "idMun: <input type='text' style='color: #F00;background-color: #ccc;' name='idMun' value='$codigo' readonly />";
						// enviamos oculto el código de la tabla municipio de las playas visualizado
						echo "<input type='hidden' name='idMunicipio' value='$codigo' />";
						// Con este código deberemos de mostrar en modo edición los datos de Nombre corto, Nombre, Descripción y PVP
						echo "<fieldset><legend>idPlaya: </legend><input type='text' name='nombre_corto' value='$idPlaya' size='10' /></fieldset>";
						echo "<fieldset><legend>Nombre: </legend><textarea name='nombre' rows='3' cols='50' >$nombre</textarea></fieldset>";
						echo "<fieldset><legend>Descripci&oacute;n: </legend><textarea name='descripcion' rows='7' cols='50' >$descripcion)</textarea></fieldset>";
						echo "<fieldset><legend>direcci&oacute;n: </legend><textarea name='direccion' rows='7' cols='50' >$direccion)</textarea></fieldset>";
						echo "<fieldset><legend>Tamaño playa: </legend><textarea name='playaSize' rows='7' cols='50' >$playaSize)</textarea></fieldset>";
						echo "<fieldset><longitud: </legend><textarea name='longitud' rows='7' cols='50' >$longitud)</textarea></fieldset>";
						echo "<fieldset><legend>Latitud: </legend><textarea name='latitud' rows='7' cols='50' >$latitud)</textarea></fieldset>";
						echo "<p><strong>Imagen: </strong>". "<img width='200' height='200' src='./blob.php?id=". $idPlaya ."' alt='Imagen de la playa'/></p>";
						
						echo "</form>";
					}
				}
			?>
		</div>
	</body>
</html>