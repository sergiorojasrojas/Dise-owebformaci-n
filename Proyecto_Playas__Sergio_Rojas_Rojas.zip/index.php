<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<title>Index</title></head>
	<LINK REL="stylesheet" TYPE="text/css" HREF="playas.css">

<body>
<?php
 

?>
<div>
	<center>
		<form action="mostrarmunicipios.php" method="post">
   <input type="submit" value="Mostrar municipios" name="municipios" />
</form>
<br>

</form>	
<br>	
<center>
		<form action="listadoplayas.php" method="post">
   <input type="submit" value="Mostrar listado playas " name="listadoplayas" />
</form>
<br>
<center>
<br>	
<center>
		<form action="altaplayas.php" method="post">
   <input type="submit" value="Alta playas" name="mostrar playas" />
   <br>	
<center>

</form>
<br>	
<center>
		<form action="playasubicacion.php" method="post">
   <input type="submit" value="Ubicacion de Playas" name="mostrar playas" />
   <br>	
<center>

</form>
<br>	

<br>	





</div>
</body>
</html>