<?php 
// Se abre la base de datos para poder capturar los posibles errores
try {
    $dwes = new PDO("mysql:host=localhost;dbname=playasdb", "dwes", "abc123.");
    $dwes->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}catch (PDOException $e) {
    $error = $e->getCode();
    $mensaje = $e->getMessage();
}

header("Content-type: image/gif"); 
if(isset($_GET['id'])){ 
    $id = $_GET['id']; 

    $sql = "SELECT imagen FROM playas";
    $sql .= " WHERE idPlaya='" . $id . "'";
	// En este apartado tendremos que ejecutar la consulta anterior
	$resultado = $dwes->query($sql);
	// si existen datos...
	if($resultado) {
		// se lee el primer registro encontrado
		$row = $resultado->fetch();
    	$img = $row['imagen'];
    }
     
    echo "$img"; 
} 
?>