<?php 
function dbConnect() {     
    $conn = new MySQLI('localhost', 'dwes', 'abc123.', 'playasdb');     
    $conn->set_charset("utf8");     
    return $conn;     
} 
 
$mysqli = dbConnect(); 
 
$tienda = $mysqli->query("SELECT * FROM playas where idMun=1")->fetch_array(MYSQLI_ASSOC);  
?>
 
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Centrar un mapa y pintar un marcador a partir de las coordenadas geográficas de latitud y longitud</title>
        <style type="text/css">
            html { height: 100% }
            body { height: 100%; margin: 0px; padding: 0px }
            #map_canvas { height: 100%; width: 100% }
        </style>
        <script type="text/javascript" src="https://maps.google.com/maps/api/js?sensor=false"></script>
        <script type="text/javascript">
 
            function init() {
 
                var latlng = new google.maps.LatLng(<?php echo $tienda['latitud']; ?>, <?php echo $tienda['longitud']; ?>);
 
                var myOptions = {
                    zoom: 12,
                    center: latlng,
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                };
 
                var map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
 
                sucursal = new google.maps.Marker({
                    position: latlng,
                    icon: 'https://maps.google.com/mapfiles/ms/icons/green-dot.png',
                    map: map
                }); 
                 
            }
 
            window.onload = init;
 
        </script>
    </head>
    <body>
        <div id="map_canvas"></div>       
    </body>
</html>
 
  </body>
</html>