<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "
http://www.w3.org/TR/html4/loose.dtd">


<html>
    <head><div style="text-align:left;padding:1em 0;"> <h3><a style="text-decoration:none;" href="https://www.zeitverschiebung.net/es/country/gb"><span
		style="color:gray;">Hora actual en</span><br />Islas Canarias Ciudad de La Laguna Tenerife</a></h3> <iframe 
		src="https://www.zeitverschiebung.net/clock-widget-iframe-v2?language=es&size=medium&timezone=Europe%2FLondon"
		width="100%" height="115" frameborder="0" seamless></iframe> </div>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Pagina de Listado de Playas de  Sergio Rojas Rojas</title>
        <!-- usamos la hoja de estilos que se indica en la tarea -->
        <link href="playas.css" rel="stylesheet" type="text/css">
		<script language="JavaScript" type="text/javascript">
 
function alertMessage(){
     alert ("Bienvenido a la pagina web de Sergio Rojas Rojas:UBICACION DE PLAYAS!")
}
</script>
    </head>
		


    <body>
	<input type='Submit' value="Ir a Index" name=Accion id=Accion OnClick="window.location.href='index.php'"> 
	<br>
	<br>
	<form action="listadoplayas.php" method="post">
   <input type="submit" value="Mostrar informacion  playas " name="listadoplayas" />
</form>
	<br>	
<br>	
	<form action="ubicaciongoogle.php" method="post">
   <input type="submit" value="Ubicacion Google en pruebas " name="listadoplayas" />
</form>
        <?php
			
            if (isset($_POST['idMun'])) $codigo = $_POST['idMun'];
			// Se abre la base de datos para poder capturar los posibles errores
            try {
                $dwes = new PDO("mysql:host=localhost;dbname=playasdb", "dwes", "abc123.");
                $dwes->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            }catch (PDOException $e) {
                $error = $e->getCode();
                $mensaje = $e->getMessage();
            }
		?>
		<div id="encabezado">
			<h1> Sergio Rojas Rojas:Listado de playas:</h1>
            <!-- Por otro lado tendremos que abrir  un formulario que envíe los datos via post a la propia página -->
			<form id="form_listado" action="<?php $_SERVER['PHP_SELF'] ?>" method="post">
				<span>Listado de Playas: </span>
                <!--  En esta parte tendremos que comenzar a configurar el combo que contendrá los datos de llos municipios -->
				<select name="idMunicipio">
					<?php
						// Si no han ocurrido errores en la apertura de la base de datos
						if (!isset($error)) {
							// Seleccionamos los campos  de la tabla playas
							$sql = "SELECT idPlaya, idMun, nombre, descripcion, direccion, playaSize, longitud, latitud, imagen FROM playas";
							//  En este apartado tendremos que ejecutar la consulta anterior sobre la BD abierta
							$resultado = $dwes->query($sql);
							
							if($resultado) {
								// Se lee el primer registro encontrado
								$row = $resultado->fetch();
								
								while ($row != null) {
									// En este apartado se va  usar la orden de html 'option' con el valor del dato del municipio leido
									echo "<option value='${row['idMun']}'";
									// Si se recibe un código de playa lo seleccionamos
								
								   
									//if (isset($codigo) && $codigo == $row['idMun'])
									if (isset($codigo) && $codigo == $row['idMun'])
										echo " selected='true'";
									// Posteriormente se tendrá que cerrar  el option poniendo el dato del nombre del municipio
									
									echo ">".htmlentities($row['nombre'])."</option>";
									// Se lee un nuevo registro 
									$row = $resultado->fetch();
								}
							}
						}
					?>
				</select>
               
		<div id="contenido">
			<h2>Listado de Playas:</h2>
			
		</div>
	</body>
</html>