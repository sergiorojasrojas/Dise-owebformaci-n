<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "
http://www.w3.org/TR/html4/loose.dtd">
<!-- 
    Esta página web solamente se dedicará a redirigir a la página "listadoplayas.php", pero si en el formulario anterior se ha pulsado 
    "Actualizar" (y no "Cancelar"), antes de redirigir debe ejecutar una consulta para cambiar los 
    datos del producto.
 -->
<html>
    <head><div style="text-align:left;padding:1em 0;"> <h3><a style="text-decoration:none;" href="https://www.zeitverschiebung.net/es/country/gb"><span
		style="color:gray;">Hora actual en</span><br />Islas Canarias Ciudad de La Laguna Tenerife</a></h3> <iframe 
		src="https://www.zeitverschiebung.net/clock-widget-iframe-v2?language=es&size=medium&timezone=Europe%2FLondon"
		width="100%" height="115" frameborder="0" seamless></iframe> </div>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <!-- Si no se pulsa el botón de aceptar, a los diez segundos se redirige a listadoplayas.php -->
        <meta http-equiv="refresh" content="10; url=listadoplayas.php" />	
        <title>Sergio Rojas Rojas. Pagina Web: Actualizar lista de Playas</title>
        <link href="playas.css" rel="stylesheet" type="text/css">
		<script language="JavaScript" type="text/javascript">

function alertMessage(){
     alert ("Bienvenido a la pagina web de Sergio Rojas Rojas: ACTUALIZAR LISTA DE PLAYAS!")
}
    </head>
		

</script>
    <body>
        <?php
			// si se ha recibido el código del producto por post, se asigna su valor a la variable codigo
            if (isset($_POST['idMun'])) $codigo = $_POST['idMun'];
			// En este código se abre la base de datos y se almacenan los posibles errores
            try {
                $dwes = new PDO("mysql:host=localhost;dbname=playasdb", "dwes", "abc123.");
                $dwes->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            }catch (PDOException $e) {
                $error = $e->getCode();
                $mensaje = $e->getMessage();
            }
		?>
		<div id="contenido">
			<h2>PLAYAS:</h2>
			<?php
				//Este codigo es para que si  se recibió un codigo de municipio y no se produjo ningun error
				// mostramos los datos de ese municipio
				if (!isset($error) && isset($codigo)) {
					//Posteriormente inicializamos las variables con sus correspondientes datos
					// recibidos por post, y una variable 'ok' que usaremos para comprobar 
					// si la grabación se ha realizado de forma correcta
					$ok=true;
					$nombre=$_POST['nombre'];
					$idPlaya=$row['idPlaya'];
					  	
					$descripcion=$row['descripcion'];
					$direccion=$row['direccion'];
					$playaSize=$row['playaSize'];
					$longitud=$row['longitud'];
					$latitud=$row['latitud'];
					$imagen=$row['imagen'];
					/* 	Realizamos una consulta que saque todos los campos de la tabla playas
					 	para el código que hemos recibido.
						Podríamos mostrar los datos sin realizar esta consulta (con los datos recibidos
						por post), pero como se tiene que realizar una actualización de un registro de 
						la tabla, es recomendable ponerla para comprobar que los datos se han recibido correctamente
					*/
					$sql="SELECT * FROM playas WHERE idMun='$codigo'";
					echo "<form id'form_actualiza' action='index.php' method='post'>";
					// Mostramos los datos descativando la edición
					echo "<p>C&Oacute;DIGO: <b>$codigo</b></p>";
				  	echo "<p>NOMBRE: <b><input type='text' value='$nombre' disabled /></b></p>";
				  	echo "<p>NOMBRE CORTO: <b><input type='text' value='$nombre_corto' disabled /></b></p>";
					
				  	echo "<p>DECRIPCI&Oacute;N: <b><input type='text' size='70' value='".substr($descripcion,0,60)."...' disabled /></b></p>";
				  	echo "<p>Direccion: <b><input type='text' value='$direccion' disabled /></b></p>";
				  	echo "<p>Playa Size: <b><input type='text' value='$playaSize' disabled /></b></p>";
						echo "<p>Longitud: <b><input type='text' value='$longitud' disabled /></b></p>";
							echo "<p>Latitud: <b><input type='text' value='$pLatitud' disabled /></b></p>";
								echo "<p>imagen: <b><input type='text' value='$imagen' disabled /></b></p>";
					// Comprobamos si se ha pulsado el botón de actualizar
					if(isset($_POST['actualiza'])){
						// Por otro lado empezaremos a comenzar el proceso de actualización de datos
						$dwes->beginTransaction();
						// En este apartado se actualizará los datos almacenados en el registro con los recibidos por post
						$sql = "UPDATE playas SET nombre='$nombre',descripcion='$descripcion',direccion='$direccion,PlayaSize='$playaSize',longitud='$longitud',latitud='$latitud',imagen='$imagen' ";
						$sql .= "WHERE idMun='$codigo'";
						// Ejecutamos la actualización y cambiamos el valor de ok si se ha producido un error
						if ($dwes->exec($sql) == 0) $ok = false;
						// si todo ha sido correcto se actualiza la tabla de forma definitiva
						if($ok==true){
							$dwes->commit();
							echo "<h2>Se han actualizado los datos. En 10 segundos volveremos a la pagina Principal Listado de Playas.MUCHAS GRACIAS</h2>";
						// En este apartado si se sabe que  hubo algún error se deshace la actualización de los datos
						}else{
							$dwes->rollback();
							echo "<h2>LO SENTIMOS MUCHO,NO HA SIDO POSIBLE ACTUALIZAR LOS DATOS</p>";
						}
						// Se libera la variable que contenía los datos de la base de datos
						unset($dwes);
					// Si hemos pulsado sobre el botón de cancelar
					}else{
						echo "<h2>Ha pulsado 'cancelar'</h2>";
					}
					// En este aparatado si pulsamos el botón de continuar nos vamos a la página principal
					
					echo "<input type='hidden' name='idMun' value='$municipio' />";
					echo "<input type='submit' value='continuar' name='continua' />";
					echo "</form>";
				}

			?>
		</div>
	</body>
</html>