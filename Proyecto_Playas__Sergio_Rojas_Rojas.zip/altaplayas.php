<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "
http://www.w3.org/TR/html4/loose.dtd">


<html>
    <head><div style="text-align:left;padding:1em 0;"> <h3><a style="text-decoration:none;" href="https://www.zeitverschiebung.net/es/country/gb"><span
		style="color:gray;">Hora actual en</span><br />Islas Canarias Ciudad de La Laguna Tenerife</a></h3> <iframe 
		src="https://www.zeitverschiebung.net/clock-widget-iframe-v2?language=es&size=medium&timezone=Europe%2FLondon"
		width="100%" height="115" frameborder="0" seamless></iframe> </div>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Pagina de Listado de Playas de  Sergio Rojas Rojas</title>
        <!-- usamos la hoja de estilos que se indica en la tarea -->
        <link href="playas.css" rel="stylesheet" type="text/css">
		<script language="JavaScript" type="text/javascript">
 
function alertMessage(){
     alert ("Bienvenido a la pagina web de Sergio Rojas Rojas: ALTA  DE PLAYAS!")
}
</script>
    </head>
		


    <body>
	<input type='Submit' value="Ir a Index" name=Accion id=Accion OnClick="window.location.href='index.php'"> 
	<br>	
<br>	
 
		
       
					<?php
					
							
									
						if ($municipio !=null && $nombre !=null && $descripcion !=null && $direccion !=null && $playaSize !=null && $longitud != null && $latitud !=null && $imagen !=null){
                            $municipio=$row['idMun'];
							$nombre=$row['nombre'];
							$descripcion=$row['descripcion'];
							$direccion=$row['direccion'];
							$playaSize=$row['playaSize'];
							$longitud=$row['longitud'];
							$latitud=$row['latitud'];
							$imagen=$row['imagen'];
        $conexion = new PDO("mysql:host=localhost;dbname=playasdb", "dwes", "abc123.");
        $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);                
        $conexion->exec("set names utf8");
        
       $sql = "INSERT INTO playas(idMun, nombre, descripcion, direccion, playaSize, longitud, latitud, imagen)";
        $sql .= " VALUES('" . $municipio . "','" . $nombre . "','". $descripcion . "','". $direccion . "','". $playaSize . "',";
        $sql .= " '" . $longitud . "','" . $latitud . "','" . $imagen ."')";
	   $resultado = $dwes->query($sql);
				
				
			 
			  
					if($resultado) {
						// se lee el primer registro encontrado
						$row = $resultado->fetch();
						
						while ($row != null) {
							// Creamos un formulario por cada registro encontrado
							// Posteriormente con los valores obtenidos y los enviamos via post al fichero editar.php
							echo '<form id="form" action="editar.php" method="post">';
							
						  	$municipio=$row['idMun'];
							$nombre=$row['nombre'];
							$descripcion=$row['descripcion'];
							$direccion=$row['direccion'];
							$playaSize=$row['playaSize'];
							$longitud=$row['longitud'];
							$latitud=$row['latitud'];
							$imagen=$row['imagen'];
							
							
							// Pasamos oculto el código de la playa  y motraremos posteriormente el
							// nombre y descripcion
							echo "<input type='hidden' name='idMun' value='$idMun'/>";
							echo "<p>nombre <b>$nombre</b> descripcion: <b>$descripcion;</b>";
							echo "<p>direccion <b>$direccion</b> playaSize: <b>$playaSize;</b>";
							echo "<p>longitud <b>$longitud</b> latitud: <b>$latitud;</b>";
							// para mostrar la imagen tienes que hacer una llamada a otro
							//php que te añada un HEADER de imagen
							echo "<p><strong>Imagen: </strong>". "<img width='200' height='200' src='./blob.php?id=". $idPlaya ."' alt='Imagen de la playa'/></p>";
							//echo "<p>imagen <b>$imagen</b>";
							// ponemos el botón de 'editar' para cada registro encontrado
							echo "<input type='submit' value='Editar' name='edit'/></p>";
							echo "</form>";
							
							$row = $resultado->fetch();
							 }
						}
						}
					?>
					
		<div id="encabezado">
			<h1> Sergio Rojas Rojas:Alta de Playas:</h1>
            <!-- Por otro lado tendremos que abrir  un formulario que envíe los datos via post a la propia página -->
			<form id="form_listado" action="<?php $_SERVER['PHP_SELF'] ?>" method="post">
				<span>Listado de alta de : </span>		
	</body>
	</html>